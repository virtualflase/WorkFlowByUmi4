export default {
  'app.pwa.offline': '当前处于离线状态',
  'app.pwa.serviceworker.updated': '有新内容',
  'app.pwa.serviceworker.updated.hint': '请点击“刷新”按钮或者手动刷新页面',
  'app.pwa.serviceworker.updated.ok': '刷新',
};
