import React from 'react';

function EndNode(){
    return (<div className="end-node">
        <div className="end-node-circle"></div>
        <div className="end-node-text">流程结束</div>
    </div>)
}

export default EndNode